#!/bin/bash

#print the current date
date

#print the disk free statistics
df -h


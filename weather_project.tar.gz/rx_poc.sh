#!/bin/bash
#define the url for wttp.in
weather_url="https://wttr.in/casablanca"

#Get today's date in wanted syntax
#+ here is a format specifier
datestamp=$(date +'%Y%m%d')

#download weather report and save it to a datestamped file
#curl is used to perform downloads from urls
curl -s "$weather_url" > "raw_data_$datestamp.txt"

#Exercise 3.1.1

obs_tmp=$(grep '°C' raw_data_20240606.txt  | sed -n 's/.*\([0-9][0-9]\).*/\1°C/p' | head -n 1)
echo "Today's temperature in Casablance is: $obs_tmp"


#Exercise 3.1.2
#There are two possible formats for the temeperature xx or +xx(yy)

#if temperature is in format xx
#grep '°C' raw_data_$datestamp.txt | awk 'NR==2 {count=0; for(i=1; i<=NF; i++) {if($i ~ /°C/) {count++; if(count==2) {print $(i-1); break}}}}'

#if the temperature is in format +xx(yy)
fc_tmp=$(grep '°C' raw_data_$datestamp.txt | awk 'NR==2 {count=0; for(i=1; i<=NF; i++) {if($i ~ /°C/) {count++; if(count==2) {print $(i-1); break}}}}' | sed 's/\033\[[0-9;]*m//g' | sed 's/.*(//' | sed 's/)//' | sed -n 's/.*\([0-9][0-9]\).*/\1°C/p')
echo "Tomorrow's temeperature in Casablance at noon is: $fc_tmp"

#Exercise 3.2
current_hour=$(TZ='Morocco/Casablanca' date +"%H") 
current_day=$(TZ='Morocco/Casablanca' date +"%d")
current_month=$(TZ='Morocco/Casablanca' date +"%m")
current_year=$(TZ='Morocco/Casablanca' date +"%Y")

#Exercise 3.3
# Add the data to the end of the file in way it matches with the previously created columns
echo -e "$current_year\t$current_month\t$current_day\t$obs_tmp\t$fc_tmp" >> rx_poc.log
cat rx_poc.log
